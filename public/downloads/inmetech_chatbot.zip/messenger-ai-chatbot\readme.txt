=== InmeTech Chatbot ===
Contributors: messengerai
Tags: chatbot, ai, chat, messenger, live chat, ai agent, customer support
Requires at least: 5.6
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A floating AI chatbot widget that connects to your SaaS backend for real-time visitor conversations, lead collection, and webhook integration.

== Description ==

**InmeTech Chatbot** adds a beautiful, Intercom-style floating chat widget to every public page of your WordPress site. It connects to your external AI SaaS API so visitors can chat with your AI agent in real time.

= Key Features =

* 🤖 **AI-Powered Chat** – Connect to any compatible SaaS AI backend via a simple REST API.
* 💬 **Modern Chat Widget** – Polished, responsive UI with typing indicators, timestamps, and smooth animations.
* 📋 **Lead Collection** – Automatically prompt visitors for their name and contact info when the AI agent requests it.
* 🔗 **Webhook Integration** – Forward purchase intent and support requests to your backend via webhooks.
* 🎨 **Fully Customisable** – Primary colour, button position, bot name, avatar, and welcome message – all from the WordPress dashboard.
* 🔒 **Secure** – API key never exposed to the browser; all calls proxied through WordPress AJAX with nonce verification.
* ⚡ **Lightweight** – Zero dependencies, vanilla JS, loads only on the frontend.

= How It Works =

1. Install and activate the plugin.
2. Go to **InmeTech** in the WordPress admin menu.
3. Enter your API Base URL, Agent ID, and API Key.
4. Customise appearance and save.
5. The chat widget will appear on all public pages.

== Installation ==

1. Upload the `messenger-ai-chatbot` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Navigate to **InmeTech** to configure your API credentials and widget appearance.

== Frequently Asked Questions ==

= What SaaS backend does this work with? =
Any backend that implements the `/chat`, `/lead`, and `/webhook` REST endpoints as documented.

= Is the API key secure? =
Yes. The API key is stored in the WordPress database and all API calls are proxied through the server—never exposed to the visitor's browser.

= Can I customise the look? =
Yes. You can change the primary colour, bot name, avatar, welcome message, and button position from the settings page.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
