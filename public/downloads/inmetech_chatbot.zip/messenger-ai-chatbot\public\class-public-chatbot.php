<?php
/**
 * Public-facing Chatbot Loader.
 *
 * Enqueues the JS & CSS widget assets on the frontend and
 * passes configuration via wp_localize_script.
 *
 * @package Messenger_AI_Chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MAIC_Public_Chatbot {

	/** @var array Merged settings. */
	private $settings;

	public function __construct() {
		$this->settings = wp_parse_args( get_option( 'maic_settings', array() ), maic_get_defaults() );

		// Only load when enabled.
		if ( '1' !== $this->settings['enabled'] ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_footer',          array( $this, 'render_widget_html' ) );
	}

	/*----------------------------------------------------------
	# Enqueue Frontend Assets
	----------------------------------------------------------*/
	public function enqueue_assets() {
		// Google Font – Inter for modern typography.
		wp_enqueue_style(
			'maic-google-font',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
			array(),
			null
		);

		// Widget CSS.
		wp_enqueue_style(
			'maic-chatbot-css',
			MAIC_PLUGIN_URL . 'assets/css/chatbot.css',
			array(),
			MAIC_VERSION
		);

		// Widget JS – loaded in footer.
		wp_enqueue_script(
			'maic-chatbot-js',
			MAIC_PLUGIN_URL . 'assets/js/chatbot.js',
			array(),
			MAIC_VERSION,
			true
		);

		// Pass config to JS (Includes local visual settings).
		wp_localize_script( 'maic-chatbot-js', 'MAIC_Config', array(
			'ajax_url'        => admin_url( 'admin-ajax.php' ),
			'nonce'           => wp_create_nonce( 'maic_chat_nonce' ),
			'button_position' => esc_attr( $this->settings['button_position'] ),
			'bot_name'        => esc_attr( $this->settings['bot_name'] ),
			'welcome_message' => esc_textarea( $this->settings['welcome_message'] ),
			'bot_avatar_url'  => esc_url( $this->settings['bot_avatar_url'] ),
			'widget_theme'    => esc_attr( $this->settings['widget_theme'] ),
			'primary_color'   => esc_attr( $this->settings['primary_color'] ),
			'secondary_color' => esc_attr( $this->settings['secondary_color'] ),
			'use_gradient'    => esc_attr( $this->settings['use_gradient'] ),
			'messenger_url'   => esc_attr( $this->settings['messenger_url'] ),
			'whatsapp_url'    => esc_attr( $this->settings['whatsapp_url'] ),
			'telegram_url'    => esc_attr( $this->settings['telegram_url'] ),
		) );
	}

	/*----------------------------------------------------------
	# Render Widget Markup (injected before </body>)
	----------------------------------------------------------*/
	public function render_widget_html() {
		$pos = $this->settings['button_position'];
		?>
		<!-- InmeTech Chatbot Widget -->
		<div id="maic-widget-root" class="maic-position-<?php echo esc_attr( $pos ); ?>">

			<!-- Floating Trigger Button -->
			<button id="maic-trigger" aria-label="<?php esc_attr_e( 'Open chat', 'messenger-ai-chatbot' ); ?>">
				<svg id="maic-icon-chat" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
				<svg id="maic-icon-close" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="display:none"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
			</button>

			<!-- Chat Window -->
			<div id="maic-chat-window" class="maic-hidden" role="dialog" aria-label="<?php esc_attr_e( 'Chat window', 'messenger-ai-chatbot' ); ?>">
				<!-- Header -->
				<div id="maic-chat-header">
					<div class="maic-header-left">
						<div id="maic-bot-avatar"></div>
						<div class="maic-header-info">
							<span id="maic-bot-name"></span>
							<span class="maic-status"><span class="maic-status-dot"></span> Online</span>
						</div>
					</div>
					<button id="maic-minimize" aria-label="<?php esc_attr_e( 'Minimize chat', 'messenger-ai-chatbot' ); ?>">
						<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>
					</button>
				</div>

				<!-- Messages -->
				<div id="maic-messages"></div>

				<!-- Input Area -->
				<div id="maic-input-container">
					<div id="maic-input-area">
						<textarea id="maic-user-input" rows="1" placeholder="<?php esc_attr_e( 'Type a message…', 'messenger-ai-chatbot' ); ?>"></textarea>
						<button id="maic-send" aria-label="<?php esc_attr_e( 'Send message', 'messenger-ai-chatbot' ); ?>">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
						</button>
					</div>
					<div class="maic-branding">
						Powered by <a href="https://inmetech.com" target="_blank">InmeTech.com</a>
					</div>
				</div>
			</div>

			<!-- Quick Contact Icons (Hidden by default, animated on trigger) -->
			<div id="maic-social-icons">
				<!-- Icons will be injected by JS depending on settings -->
			</div>
		</div>
		<!-- /InmeTech Chatbot Widget -->
		<?php
	}
}
