/**
 * Messenger AI Chatbot – Frontend Widget Script
 *
 * Handles chat window toggle, message sending via WordPress AJAX proxy,
 * lead collection form, webhook dispatch, typing indicator, and
 * auto-growing textarea.
 *
 * All API calls go through the WordPress AJAX proxy so the API key
 * is never exposed to the browser.
 *
 * @package Messenger_AI_Chatbot
 */

(function () {
	'use strict';

/* ====================================================
	   State & References
	==================================================== */
	let root, trigger, chatWindow, iconChat, iconClose, minimize, messages, userInput, sendBtn, botNameEl, avatarEl, CFG;
	let isOpen = false;
	const sessionId = generateId();
	let userInfo = {
		name: localStorage.getItem('maic_user_name') || '',
		email: localStorage.getItem('maic_user_email') || '',
		phone: localStorage.getItem('maic_user_phone') || ''
	};

	/* ====================================================
	   Initialization
	==================================================== */
	function init() {
		// Capture DOM references now that DOM is ready
		root        = document.getElementById('maic-widget-root');
		trigger     = document.getElementById('maic-trigger');
		chatWindow  = document.getElementById('maic-chat-window');
		iconChat    = document.getElementById('maic-icon-chat');
		iconClose   = document.getElementById('maic-icon-close');
		minimize    = document.getElementById('maic-minimize');
		messages    = document.getElementById('maic-messages');
		userInput   = document.getElementById('maic-user-input');
		sendBtn     = document.getElementById('maic-send');
		botNameEl   = document.getElementById('maic-bot-name');
		avatarEl    = document.getElementById('maic-bot-avatar');
		CFG         = window.MAIC_Config || {};

		// Abort if essential elements are missing
		if (!root || !trigger || !chatWindow) return;

		// Apply local config immediately for zero-layout-shift
		applyConfig(CFG);

		// Fetch remote config from SaaS via WP Proxy if needed (for other logic)
		fetchConfig();

		// Event listeners (with safety checks)
		if (trigger) trigger.addEventListener('click', toggleChat);
		if (minimize) minimize.addEventListener('click', toggleChat);
		if (sendBtn) sendBtn.addEventListener('click', handleSend);
		if (userInput) {
			userInput.addEventListener('keydown', onInputKeydown);
			userInput.addEventListener('input', autoGrow);
		}
	}

	function fetchConfig() {
		const formData = new FormData();
		formData.append('action', 'maic_fetch_config');
		formData.append('nonce', CFG.nonce);

		fetch(CFG.ajax_url, { method: 'POST', body: formData })
			.then(res => res.json())
			.then(res => {
				if (res.success && res.data && res.data.config) {
					// We only take non-visual data from remote if local is missing
					// but generally we trust local WP settings now.
				}
			})
			.catch(err => console.error('MAIC: Config sync failed', err));
	}

	function applyConfig(data) {
		// Use data if provided, else fallback to CFG (local)
		const bot_name        = data.bot_name || CFG.bot_name || 'AI Assistant';
		const welcome_message = data.welcome_message || CFG.welcome_message;
		const primary_color   = data.primary_color || CFG.primary_color || '#7C3AED';
		const secondary_color = data.secondary_color || CFG.secondary_color || '#EC4899';
		const use_gradient    = data.use_gradient === '1' || data.use_gradient === true;
		const widget_theme    = data.widget_theme || CFG.widget_theme || 'bubble';
		const bot_avatar_url  = data.bot_avatar_url || CFG.bot_avatar_url;
		const pos             = CFG.button_position || data.button_position || 'right';

		// Apply Theme Classes
		if (widget_theme) {
			root.classList.remove('maic-theme-bubble', 'maic-theme-glass', 'maic-theme-minimal');
			root.classList.add('maic-theme-' + widget_theme);
		}

		// Apply Colors
		if (use_gradient && secondary_color) {
			const grad = `linear-gradient(135deg, ${primary_color}, ${secondary_color})`;
			root.style.setProperty('--maic-bg-grad', grad);
		} else {
			root.style.setProperty('--maic-bg-grad', primary_color);
		}
		root.style.setProperty('--maic-primary', primary_color);

		// Apply Position
		root.classList.remove('maic-position-right', 'maic-position-left');
		root.classList.add('maic-position-' + pos);

		// Update UI Text
		botNameEl.textContent = bot_name;
		if (bot_avatar_url) {
			avatarEl.style.backgroundImage = `url(${bot_avatar_url})`;
			avatarEl.style.backgroundSize = 'cover';
			avatarEl.textContent = '';
		} else {
			avatarEl.style.backgroundImage = 'none';
			avatarEl.textContent = bot_name.charAt(0).toUpperCase();
		}

		// Update local references for toggleChat
		CFG.welcome_message = welcome_message;
		CFG.bot_name = bot_name;
		CFG.bot_avatar_url = bot_avatar_url;
	}

	/* ====================================================
	   Toggle Chat Window
	==================================================== */
	function toggleChat() {
		isOpen = !isOpen;
		chatWindow.classList.toggle('maic-hidden', !isOpen);
		iconChat.style.display  = isOpen ? 'none' : 'block';
		iconClose.style.display = isOpen ? 'block' : 'none';

		// Social Icons Animation (now shows when OPEN, hides when CLOSED)
		const socialContainer = document.getElementById('maic-social-icons');
		if (socialContainer) {
			if (isOpen) {
				renderSocialIcons(socialContainer);
				setTimeout(() => socialContainer.classList.add('maic-social-visible'), 50);
			} else {
				socialContainer.classList.remove('maic-social-visible');
				setTimeout(() => socialContainer.innerHTML = '', 400); 
			}
		}

		if (isOpen) {
			trackEvent('click');
			if (messages.children.length === 0 && CFG.welcome_message) {
				appendMessage('bot', CFG.welcome_message);
			}
			userInput.focus();
			scrollToBottom();
		}
	}

	function renderSocialIcons(container) {
		container.innerHTML = '';
		const icons = [];
		
		if (CFG.messenger_url) {
			icons.push({
				id: 'messenger',
				url: 'https://m.me/' + CFG.messenger_url,
				color: '#0084FF',
				svg: '<svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.14 2 11.25c0 2.91 1.45 5.49 3.72 7.12V22l3.5-1.92c.88.24 1.81.37 2.78.37 5.52 0 10-4.14 10-9.25S17.52 2 12 2zm1.14 12.33l-2.58-2.75-5.04 2.75 5.54-5.89 2.58 2.75 5.04-2.75-5.54 5.89z"/></svg>'
			});
		}
		if (CFG.whatsapp_url) {
			const waNum = CFG.whatsapp_url.replace(/\D/g, '');
			icons.push({
				id: 'whatsapp',
				url: 'https://wa.me/' + waNum,
				color: '#25D366',
				svg: '<svg width="22" height="22" fill="#ffffff" viewBox="0 0 24 24"><path d="M12.004 2C6.48 2 2.004 6.48 2.004 12c0 1.88.52 3.63 1.43 5.14l-1.43 5.14 5.31-1.43c1.47.88 3.22 1.43 5.14 1.43 5.52 0 10-4.48 10-10s-4.48-10-10-10zm.003 18.06c-1.63 0-3.14-.42-4.43-1.16l-.32-.19-3.15.85.85-3.15-.19-.32c-.74-1.29-1.16-2.8-1.16-4.43 0-4.63 3.77-8.4 8.4-8.4s8.4 3.77 8.4 8.4-3.77 8.4-8.4 8.4z"/></svg>'
			});
		}
		if (CFG.telegram_url) {
			icons.push({
				id: 'telegram',
				url: 'https://t.me/' + CFG.telegram_url,
				color: '#0088CC',
				svg: '<svg width="18" height="18" fill="#ffffff" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.14 17.01c-.13.01-.26 0-.38-.05-.12-.05-.23-.13-.31-.22-.08-.1-.13-.21-.15-.34-.02-.13-.01-.26.04-.38l.45-1.25.13-.36-1.58-.75c-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.11.02-1.93 1.23-5.46 3.62-.51.35-.98.52-1.4.51-.46-.01-1.35-.26-2.01-.48-.81-.27-1.45-.42-1.39-.88.03-.24.37-.48 1.01-.74 3.94-1.72 6.56-2.85 7.87-3.39 3.75-1.55 4.53-1.82 5.04-1.83.11 0 .36.03.52.16.14.11.18.26.2.37.03.11.03.3.01.46z"/></svg>'
			});
		}

		icons.forEach((icon, index) => {
			const a = document.createElement('a');
			a.href = icon.url;
			a.target = '_blank';
			a.className = 'maic-social-icon';
			a.style.backgroundColor = icon.color;
			a.style.transitionDelay = (index * 0.05) + 's';
			a.innerHTML = icon.svg;
			container.appendChild(a);
		});
	}

	/* ====================================================
	   Tracking
	==================================================== */
	function trackEvent(type) {
		if (typeof sessionStorage === 'undefined') return;
		const key = 'maic_track_' + type;
		if (sessionStorage.getItem(key)) return;

		const formData = new FormData();
		formData.append('action', 'maic_track_event');
		formData.append('nonce', CFG.nonce);
		formData.append('type', type);

		fetch(CFG.ajax_url, { method: 'POST', body: formData })
			.then(function () { sessionStorage.setItem(key, '1'); })
			.catch(function () {});
	}

	// Track view on load.
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () { trackEvent('view'); });
	} else {
		trackEvent('view');
	}

	/* ====================================================
	   Send Message
	==================================================== */
	function handleSend() {
		const text = userInput.value.trim();
		if (!text) return;

		userInput.value = '';
		userInput.style.height = 'auto';

		appendMessage('user', text);
		showTyping();

		const formData = new FormData();
		formData.append('action', 'maic_chat_request');
		formData.append('nonce', CFG.nonce);
		formData.append('message', text);
		formData.append('session_id', sessionId);
		formData.append('user_name', userInfo.name);
		formData.append('user_email', userInfo.email);
		formData.append('user_phone', userInfo.phone);

		fetch(CFG.ajax_url, { method: 'POST', body: formData })
			.then(res => res.json())
			.then(res => {
				hideTyping();
				if (res.success && res.data && res.data.reply) {
					appendMessage('bot', res.data.reply);
				} else {
					appendMessage('bot', 'Sorry, I am having trouble responding right now.');
				}
			})
			.catch(() => {
				hideTyping();
				appendMessage('bot', 'Connection error. Please try again.');
			});
	}

	/* ====================================================
	   Append Message Bubble
	==================================================== */
	function appendMessage(role, text) {
		const wrapper = document.createElement('div');
		wrapper.className = 'maic-msg-row';

		if (role === 'bot') {
			const av = document.createElement('div');
			av.className = 'maic-avatar-sm';
			if (CFG.bot_avatar_url) {
				av.style.backgroundImage = `url(${CFG.bot_avatar_url})`;
			} else {
				av.textContent = (CFG.bot_name || 'AI').charAt(0).toUpperCase();
			}
			wrapper.appendChild(av);
		} else {
			// User message - add a spacer if we want bot avatar on left only
			// Or we could add a user avatar here.
		}

		const msg = document.createElement('div');
		msg.className = 'maic-msg maic-msg-' + role;
		msg.innerHTML = formatMessage(text);
		wrapper.appendChild(msg);

		messages.appendChild(wrapper);
		scrollToBottom();
	}

	/* ====================================================
	   Typing Indicator
	==================================================== */
	function showTyping() {
		if (document.getElementById('maic-typing')) return;

		const row = document.createElement('div');
		row.className = 'maic-msg-row';
		row.id = 'maic-typing';

		const avatar = document.createElement('div');
		avatar.className = 'maic-avatar-sm';
		if (CFG.bot_avatar_url) {
			avatar.style.backgroundImage = `url(${CFG.bot_avatar_url})`;
		} else {
			avatar.textContent = (CFG.bot_name || 'AI').charAt(0).toUpperCase();
		}

		const dots = document.createElement('div');
		dots.className = 'maic-typing';
		dots.innerHTML = '<span></span><span></span><span></span>';

		row.appendChild(avatar);
		row.appendChild(dots);
		messages.appendChild(row);
		scrollToBottom();
	}

	function hideTyping() {
		const el = document.getElementById('maic-typing');
		if (el) el.remove();
	}

	/* ====================================================
	   Webhook (called from bot response if needed)
	==================================================== */
	// Expose globally so it can be triggered by custom logic.
	window.maicSendWebhook = function (message) {
		const formData = new FormData();
		formData.append('action', 'maic_send_webhook');
		formData.append('nonce', CFG.nonce);
		formData.append('message', message || '');
		formData.append('session_id', sessionId);
		formData.append('user_name', userInfo.name);
		formData.append('user_email', userInfo.email);
		formData.append('user_phone', userInfo.phone);

		return fetch(CFG.ajax_url, { method: 'POST', body: formData });
	};

	/* ====================================================
	   Helpers
	==================================================== */
	function generateId() {
		return 'sess_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
	}

	function scrollToBottom() {
		requestAnimationFrame(function () {
			messages.scrollTop = messages.scrollHeight;
		});
	}

	function autoGrow() {
		this.style.height = 'auto';
		this.style.height = Math.min(this.scrollHeight, 100) + 'px';
	}

	function onInputKeydown(e) {
		if (e.key === 'Enter' && !e.shiftKey) {
			e.preventDefault();
			handleSend();
		}
	}

	/**
	 * Basic markdown-like formatting: **bold**, *italic*, `code`, \n → <br>.
	 */
	function formatMessage(text) {
		var s = text;
		// Escape HTML.
		s = s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
		// Bold.
		s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
		// Italic.
		s = s.replace(/\*(.+?)\*/g, '<em>$1</em>');
		// Inline code.
		s = s.replace(/`(.+?)`/g, '<code style="background:#f0f0f0;padding:1px 5px;border-radius:4px;font-size:13px;">$1</code>');
		// Line breaks.
		s = s.replace(/\n/g, '<br>');
		return s;
	}

	/* ====================================================
	   Boot
	==================================================== */
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

})();
