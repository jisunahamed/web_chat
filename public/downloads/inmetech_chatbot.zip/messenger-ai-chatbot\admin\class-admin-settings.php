<?php
/**
 * Admin Settings Page for InmeTech Chatbot.
 *
 * Registers a top-level menu item "InmeTech" with fields for
 * API configuration, appearance, and behaviour.
 *
 * @package Messenger_AI_Chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MAIC_Admin_Settings {

	/** Option key stored in wp_options. */
	const OPTION_KEY = 'maic_settings';

	/**
	 * Constructor – hook into WordPress.
	 */
	public function __construct() {
		add_action( 'admin_menu',    array( $this, 'register_menu' ) );
		add_action( 'admin_init',    array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/*----------------------------------------------------------
	# Menu Registration
	----------------------------------------------------------*/
	public function register_menu() {
		add_menu_page(
			__( 'InmeTech Settings', 'messenger-ai-chatbot' ),
			__( 'InmeTech', 'messenger-ai-chatbot' ),
			'manage_options',
			'messenger-ai',
			array( $this, 'render_settings_page' ),
			'dashicons-format-chat',
			80
		);
	}

	/*----------------------------------------------------------
	# Enqueue Admin CSS + Color Picker
	----------------------------------------------------------*/
	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_messenger-ai' !== $hook ) {
			return;
		}

		// WordPress colour picker.
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		// Admin stylesheet.
		wp_enqueue_style(
			'maic-admin-css',
			MAIC_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			MAIC_VERSION
		);

		// Inline script to initialise colour picker.
		wp_add_inline_script( 'wp-color-picker', "
			jQuery(document).ready(function($){
				$('.maic-color-picker').wpColorPicker();
			});
		" );
	}

	/*----------------------------------------------------------
	# Register Settings, Sections & Fields
	----------------------------------------------------------*/
	public function register_settings() {

		register_setting( 'maic_settings_group', self::OPTION_KEY, array(
			'type'              => 'array',
			'sanitize_callback' => array( $this, 'sanitize_settings' ),
			'default'           => maic_get_defaults(),
		) );

		/* --- Section: API Configuration --- */
		add_settings_section(
			'maic_section_api',
			__( 'API Configuration', 'messenger-ai-chatbot' ),
			function () {
				echo '<p class="maic-section-desc">' . esc_html__( 'Connect the chatbot to your SaaS backend.', 'messenger-ai-chatbot' ) . '</p>';
			},
			'messenger-ai'
		);

		$this->add_field( 'api_base_url',   __( 'API Base URL', 'messenger-ai-chatbot' ),   'maic_section_api', 'url' );
		$this->add_field( 'agent_id',        __( 'Agent ID', 'messenger-ai-chatbot' ),        'maic_section_api' );
		$this->add_field( 'api_key',         __( 'API Key', 'messenger-ai-chatbot' ),         'maic_section_api', 'password' );

		/* --- Section: General & Behavior --- */
		add_settings_section(
			'maic_section_general',
			__( 'General Settings', 'messenger-ai-chatbot' ),
			function () {
				echo '<p class="maic-section-desc">' . esc_html__( 'Configure basic widget behavior.', 'messenger-ai-chatbot' ) . '</p>';
			},
			'messenger-ai'
		);

		$this->add_field( 'button_position', __( 'Button Position', 'messenger-ai-chatbot' ), 'maic_section_general', 'select', array( 'right' => 'Right', 'left' => 'Left' ) );
		$this->add_field( 'enabled',         __( 'Enable Chatbot', 'messenger-ai-chatbot' ),  'maic_section_general', 'toggle' );

		/* --- Section: Appearance --- */
		add_settings_section(
			'maic_section_appearance',
			__( 'Appearance', 'messenger-ai-chatbot' ),
			function () {
				echo '<p class="maic-section-desc">' . esc_html__( 'Customize the look and feel of your chatbot.', 'messenger-ai-chatbot' ) . '</p>';
			},
			'messenger-ai'
		);

		$this->add_field( 'widget_theme',    __( 'Widget Theme', 'messenger-ai-chatbot' ),    'maic_section_appearance', 'select', array( 'bubble' => 'Bubble', 'glass' => 'Glass', 'minimal' => 'Minimal' ) );
		$this->add_field( 'bot_name',        __( 'Bot Name', 'messenger-ai-chatbot' ),        'maic_section_appearance' );
		$this->add_field( 'bot_avatar_url',  __( 'Bot Avatar URL', 'messenger-ai-chatbot' ),  'maic_section_appearance', 'url' );
		$this->add_field( 'welcome_message', __( 'Welcome Message', 'messenger-ai-chatbot' ), 'maic_section_appearance', 'textarea' );
		
		$this->add_field( 'primary_color',   __( 'Primary Color', 'messenger-ai-chatbot' ),   'maic_section_appearance', 'color' );
		$this->add_field( 'use_gradient',    __( 'Use Gradient', 'messenger-ai-chatbot' ),    'maic_section_appearance', 'toggle' );
		$this->add_field( 'secondary_color', __( 'Secondary Color', 'messenger-ai-chatbot' ), 'maic_section_appearance', 'color' );

		/* --- Section: Social Media --- */
		add_settings_section(
			'maic_section_social',
			__( 'Social Media Links', 'messenger-ai-chatbot' ),
			function () {
				echo '<p class="maic-section-desc">' . esc_html__( 'Add links to your social profiles to show them as quick icons.', 'messenger-ai-chatbot' ) . '</p>';
			},
			'messenger-ai'
		);

		$this->add_field( 'messenger_url', __( 'Messenger Username', 'messenger-ai-chatbot' ), 'maic_section_social', 'text', array( 'placeholder' => 'e.g. inmetech' ) );
		$this->add_field( 'whatsapp_url',  __( 'WhatsApp Number', 'messenger-ai-chatbot' ),   'maic_section_social', 'text', array( 'placeholder' => 'e.g. 88017...' ) );
		$this->add_field( 'telegram_url',  __( 'Telegram Username', 'messenger-ai-chatbot' ), 'maic_section_social', 'text', array( 'placeholder' => 'e.g. inme_tech' ) );
	}

	/*----------------------------------------------------------
	# Helper: Add Field
	----------------------------------------------------------*/
	private function add_field( $id, $label, $section, $type = 'text', $choices = array() ) {
		add_settings_field(
			'maic_field_' . $id,
			$label,
			array( $this, 'render_field' ),
			'messenger-ai',
			$section,
			array(
				'id'      => $id,
				'type'    => $type,
				'choices' => $choices,
			)
		);
	}

	/*----------------------------------------------------------
	# Render Individual Field
	----------------------------------------------------------*/
	public function render_field( $args ) {
		$opts  = wp_parse_args( get_option( self::OPTION_KEY, array() ), maic_get_defaults() );
		$id    = $args['id'];
		$type  = $args['type'];
		$value = $opts[ $id ] ?? '';
		$name  = self::OPTION_KEY . '[' . $id . ']';

		switch ( $type ) {
			case 'textarea':
				printf(
					'<textarea id="maic_%1$s" name="%2$s" rows="3" class="large-text">%3$s</textarea>',
					esc_attr( $id ),
					esc_attr( $name ),
					esc_textarea( $value )
				);
				break;

			case 'password':
				printf(
					'<input type="password" id="maic_%1$s" name="%2$s" value="%3$s" class="regular-text" autocomplete="new-password" />',
					esc_attr( $id ),
					esc_attr( $name ),
					esc_attr( $value )
				);
				break;

			case 'url':
				printf(
					'<input type="url" id="maic_%1$s" name="%2$s" value="%3$s" class="regular-text" placeholder="https://" />',
					esc_attr( $id ),
					esc_attr( $name ),
					esc_attr( $value )
				);
				break;

			case 'color':
				printf(
					'<input type="text" id="maic_%1$s" name="%2$s" value="%3$s" class="maic-color-picker" data-default-color="%3$s" />',
					esc_attr( $id ),
					esc_attr( $name ),
					esc_attr( $value )
				);
				break;

			case 'select':
				printf( '<select id="maic_%1$s" name="%2$s">', esc_attr( $id ), esc_attr( $name ) );
				foreach ( $args['choices'] as $k => $v ) {
					printf(
						'<option value="%1$s" %2$s>%3$s</option>',
						esc_attr( $k ),
						selected( $value, $k, false ),
						esc_html( $v )
					);
				}
				echo '</select>';
				break;

			case 'toggle':
				printf(
					'<label class="maic-toggle"><input type="checkbox" name="%1$s" value="1" %2$s /><span class="maic-toggle-slider"></span></label>',
					esc_attr( $name ),
					checked( $value, '1', false )
				);
				break;

			default: // text
				printf(
					'<input type="text" id="maic_%1$s" name="%2$s" value="%3$s" class="regular-text" />',
					esc_attr( $id ),
					esc_attr( $name ),
					esc_attr( $value )
				);
				break;
		}
	}

	/*----------------------------------------------------------
	# Sanitize Callback
	----------------------------------------------------------*/
	public function sanitize_settings( $input ) {
		$clean = array();

		$clean['api_base_url']    = esc_url_raw( $input['api_base_url'] ?? '' );
		$clean['agent_id']        = sanitize_text_field( $input['agent_id'] ?? '' );
		$clean['api_key']         = sanitize_text_field( $input['api_key'] ?? '' );
		$clean['button_position'] = in_array( $input['button_position'] ?? '', array( 'left', 'right' ), true ) ? $input['button_position'] : 'right';
		$clean['enabled']         = ! empty( $input['enabled'] ) ? '1' : '0';

		$clean['widget_theme']    = in_array( $input['widget_theme'] ?? '', array( 'bubble', 'glass', 'minimal' ), true ) ? $input['widget_theme'] : 'bubble';
		$clean['bot_name']        = sanitize_text_field( $input['bot_name'] ?? '' );
		$clean['bot_avatar_url']  = esc_url_raw( $input['bot_avatar_url'] ?? '' );
		$clean['welcome_message'] = sanitize_textarea_field( $input['welcome_message'] ?? '' );
		
		// Ensure colors are valid hex
		$clean['primary_color']   = sanitize_hex_color( $input['primary_color'] ?? '' );
		$clean['secondary_color'] = sanitize_hex_color( $input['secondary_color'] ?? '' );
		$clean['use_gradient']    = ! empty( $input['use_gradient'] ) ? '1' : '0';

		$clean['messenger_url']   = sanitize_text_field( $input['messenger_url'] ?? '' );
		$clean['whatsapp_url']    = sanitize_text_field( $input['whatsapp_url'] ?? '' );
		$clean['telegram_url']    = sanitize_text_field( $input['telegram_url'] ?? '' );

		return $clean;
	}

	/*----------------------------------------------------------
	# Render Settings Page
	----------------------------------------------------------*/
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap maic-admin-wrap">
			<div class="maic-admin-header">
				<div class="maic-admin-header-inner">
					<div class="maic-header-icon-box">
						<span class="dashicons dashicons-format-chat maic-header-icon"></span>
					</div>
					<div>
						<h1><?php esc_html_e( 'InmeTech', 'messenger-ai-chatbot' ); ?></h1>
						<p class="maic-header-tagline"><?php esc_html_e( 'Configure your premium AI chatbot widget.', 'messenger-ai-chatbot' ); ?></p>
					</div>
				</div>
			</div>

			<div class="maic-layout-split">
				<div class="maic-card maic-settings-col">
					<form method="post" action="options.php" class="maic-settings-form">
						<?php
						settings_fields( 'maic_settings_group' );
						do_settings_sections( 'messenger-ai' );
						?>
						<div class="maic-submit-container">
							<?php submit_button( __( 'Save All Changes', 'messenger-ai-chatbot' ) ); ?>
						</div>
					</form>
				</div>
				<div class="maic-preview-col">
					<div class="maic-preview-sticky">
						<h3 class="maic-preview-title"><?php esc_html_e( 'Live Widget Preview', 'messenger-ai-chatbot' ); ?></h3>
						
						<!-- Simulated Preview Window -->
						<div class="maic-preview-window" id="maic-preview-root">
							<div class="maic-preview-chat" id="maic-preview-chat">
								<div class="maic-preview-header" id="maic-preview-header">
									<div class="maic-preview-hleft">
										<div class="maic-preview-avatar" id="maic-preview-avatar"></div>
										<div class="maic-preview-hinfo">
											<div class="maic-preview-name" id="maic-preview-name">AI Assistant</div>
											<div class="maic-preview-status"><span class="maic-preview-dot"></span> Online</div>
										</div>
									</div>
								</div>
								<div class="maic-preview-body">
									<div class="maic-preview-msg-wrap">
										<div class="maic-preview-msg-avatar" id="maic-preview-msg-avatar"></div>
										<div class="maic-preview-msg-bot" id="maic-preview-msg">Hi there! 👋 How can I help you today?</div>
									</div>
									<div class="maic-preview-msg-user">Hello! I have a question.</div>
								</div>
								<div class="maic-preview-footer">
									<div class="maic-preview-input">Type a message...</div>
								</div>
							</div>
							<div class="maic-preview-trigger" id="maic-preview-trigger">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<script>
				jQuery(document).ready(function($) {
					function updatePreview() {
						var theme = $('#maic_widget_theme').val() || 'bubble';
						var pColor = $('#maic_primary_color').val() || '#7C3AED';
						var sColor = $('#maic_secondary_color').val() || '#EC4899';
						var useGrad = $('#maic_use_gradient').is(':checked');
						var bName = $('#maic_bot_name').val() || 'AI Assistant';
						var bAv = $('#maic_bot_avatar_url').val() || '';
						var bMsg = $('#maic_welcome_message').val() || 'Hi there! 👋 How can I help you today?';
						
						var bg = useGrad && sColor ? 'linear-gradient(135deg, ' + pColor + ', ' + sColor + ')' : pColor;
						var root = $('#maic-preview-root');
						
						root.removeClass('theme-bubble theme-glass theme-minimal').addClass('theme-' + theme);
						
						if (theme === 'glass') {
							$('#maic-preview-header').css('background', 'linear-gradient(135deg, '+pColor+'cc, '+(useGrad&&sColor?sColor+'cc':pColor+'99')+')');
							$('#maic-preview-trigger').css('background', bg);
							$('#maic-preview-msg.maic-preview-msg-bot').css({'background': 'rgba(255,255,255,0.7)', 'color': '#1e293b'});
						} else {
							$('#maic-preview-header').css('background', bg);
							$('#maic-preview-trigger').css('background', bg);
							$('#maic-preview-msg.maic-preview-msg-bot').css({'background': '#fff', 'color': '#1e293b'});
						}
						
						$('.maic-preview-msg-user').css('background', bg);
						
						$('#maic-preview-name').text(bName);
						$('#maic-preview-msg').text(bMsg);
						
						var abbr = bName.charAt(0).toUpperCase();
						if (bAv) {
							$('#maic-preview-avatar, #maic-preview-msg-avatar').css({'background-image': 'url('+bAv+')', 'background-size': 'cover'});
							$('#maic-preview-avatar, #maic-preview-msg-avatar').text('');
						} else {
							$('#maic-preview-avatar, #maic-preview-msg-avatar').css('background-image', 'none');
							$('#maic-preview-avatar, #maic-preview-msg-avatar').text(abbr);
							if(theme !== 'glass') {
								$('#maic-preview-msg-avatar').css({'color': pColor, 'background': pColor + '18'});
							}
						}
					}
					
					// Bind changes
					$('input, select, textarea').on('change keyup', updatePreview);
					
					// For color pickers (they use custom events)
					$('.maic-color-picker').wpColorPicker({
						change: function() { setTimeout(updatePreview, 50); }
					});
					
					// Initial run
					updatePreview();
				});
			</script>
			
			<div class="maic-admin-footer">
				<p>Powered by <a href="https://messengerai.cloud" target="_blank">InmeTech</a> &copy; <?php echo date('Y'); ?></p>
			</div>
		</div>
		<?php
	}
}
