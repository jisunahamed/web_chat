<?php
/**
 * Plugin Name: InmeTech Chatbot
 * Plugin URI:  https://developer.messengerai.cloud
 * Description: A floating AI chatbot widget that connects to an external SaaS API for real-time visitor–AI conversations, lead collection, and webhook integration.
 * Version:     1.0.0
 * Author:      InmeTech
 * Author URI:  https://messengerai.cloud
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: messenger-ai-chatbot
 * Domain Path: /languages
 *
 * @package Messenger_AI_Chatbot
 */

// Prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*--------------------------------------------------------------
# Constants
--------------------------------------------------------------*/
define( 'MAIC_VERSION', '1.0.4' );
define( 'MAIC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MAIC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'MAIC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/*--------------------------------------------------------------
# Default Options
--------------------------------------------------------------*/
function maic_get_defaults() {
	return array(
		'api_base_url'      => '',
		'agent_id'          => '',
		'api_key'           => '',
		'enabled'           => '1',
		'button_position'   => 'right',
		'bot_name'          => 'AI Assistant',
		'welcome_message'   => 'Hi there! 👋 How can I help you today?',
		'bot_avatar_url'    => '',
		'widget_theme'      => 'bubble',
		'primary_color'     => '#7C3AED',
		'secondary_color'   => '#EC4899',
		'use_gradient'      => '0',
		'messenger_url'     => '',
		'whatsapp_url'      => '',
		'telegram_url'      => '',
	);
}

/*--------------------------------------------------------------
# Activation / Deactivation
--------------------------------------------------------------*/
register_activation_hook( __FILE__, 'maic_activate' );
function maic_activate() {
	$defaults = maic_get_defaults();
	if ( false === get_option( 'maic_settings' ) ) {
		add_option( 'maic_settings', $defaults );
	}
}

register_deactivation_hook( __FILE__, 'maic_deactivate' );
function maic_deactivate() {
	// Optionally clean up transient caches here.
}

/*--------------------------------------------------------------
# Include Files
--------------------------------------------------------------*/
if ( is_admin() ) {
	require_once MAIC_PLUGIN_DIR . 'admin/class-admin-settings.php';
}
require_once MAIC_PLUGIN_DIR . 'public/class-public-chatbot.php';

/*--------------------------------------------------------------
# Initialize Plugin
--------------------------------------------------------------*/
add_action( 'plugins_loaded', 'maic_init' );
function maic_init() {
	if ( is_admin() ) {
		new MAIC_Admin_Settings();
	}

	// Only load the public widget on the frontend.
	if ( ! is_admin() || wp_doing_ajax() ) {
		new MAIC_Public_Chatbot();
	}
}

/*--------------------------------------------------------------
# AJAX: Proxy Chat Request  (avoids exposing API key to browser)
--------------------------------------------------------------*/
add_action( 'wp_ajax_maic_chat_request',        'maic_ajax_chat_request' );
add_action( 'wp_ajax_nopriv_maic_chat_request', 'maic_ajax_chat_request' );

function maic_ajax_chat_request() {
	// Verify nonce.
	check_ajax_referer( 'maic_chat_nonce', 'nonce' );

	$settings = wp_parse_args( get_option( 'maic_settings', array() ), maic_get_defaults() );

	if ( empty( $settings['api_base_url'] ) || empty( $settings['agent_id'] ) || empty( $settings['api_key'] ) ) {
		wp_send_json_error( array( 'message' => 'Chatbot is not configured.' ), 500 );
	}

	// Sanitize inputs.
	$message    = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );
	$session_id = sanitize_text_field( wp_unslash( $_POST['session_id'] ?? '' ) );
	$user_name  = sanitize_text_field( wp_unslash( $_POST['user_name'] ?? '' ) );
	$user_email = sanitize_email( wp_unslash( $_POST['user_email'] ?? '' ) );
	$user_phone = sanitize_text_field( wp_unslash( $_POST['user_phone'] ?? '' ) );

	if ( empty( $message ) || empty( $session_id ) ) {
		wp_send_json_error( array( 'message' => 'Message and session_id are required.' ), 400 );
	}

	$body = array(
		'agent_id'   => $settings['agent_id'],
		'session_id' => $session_id,
		'message'    => $message,
		'user_info'  => array(
			'name'  => $user_name,
			'email' => $user_email,
			'phone' => $user_phone,
		),
	);

	$api_url = trailingslashit( $settings['api_base_url'] ) . 'chat';

	$response = wp_remote_post( $api_url, array(
		'timeout' => 30,
		'headers' => array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . $settings['api_key'],
		),
		'body' => wp_json_encode( $body ),
	) );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( array( 'message' => $response->get_error_message() ), 502 );
	}

	$code = wp_remote_retrieve_response_code( $response );
	$data = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $code >= 400 || empty( $data ) ) {
		wp_send_json_error( array( 'message' => 'API request failed.' ), $code ?: 500 );
	}

	wp_send_json_success( $data );
}

/*--------------------------------------------------------------
# AJAX: Proxy Lead Submission
--------------------------------------------------------------*/
add_action( 'wp_ajax_maic_submit_lead',        'maic_ajax_submit_lead' );
add_action( 'wp_ajax_nopriv_maic_submit_lead',  'maic_ajax_submit_lead' );

function maic_ajax_submit_lead() {
	check_ajax_referer( 'maic_chat_nonce', 'nonce' );

	$settings = wp_parse_args( get_option( 'maic_settings', array() ), maic_get_defaults() );

	$session_id = sanitize_text_field( wp_unslash( $_POST['session_id'] ?? '' ) );
	$user_name  = sanitize_text_field( wp_unslash( $_POST['user_name'] ?? '' ) );
	$user_email = sanitize_email( wp_unslash( $_POST['user_email'] ?? '' ) );
	$user_phone = sanitize_text_field( wp_unslash( $_POST['user_phone'] ?? '' ) );

	$body = array(
		'session_id' => $session_id,
		'user_info'  => array(
			'name'  => $user_name,
			'email' => $user_email,
			'phone' => $user_phone,
		),
	);

	$api_url = trailingslashit( $settings['api_base_url'] ) . 'lead';

	$response = wp_remote_post( $api_url, array(
		'timeout' => 15,
		'headers' => array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . $settings['api_key'],
		),
		'body' => wp_json_encode( $body ),
	) );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( array( 'message' => $response->get_error_message() ), 502 );
	}

	wp_send_json_success( array( 'message' => 'Lead submitted.' ) );
}

/*--------------------------------------------------------------
# AJAX: Proxy Webhook
--------------------------------------------------------------*/
add_action( 'wp_ajax_maic_send_webhook',        'maic_ajax_send_webhook' );
add_action( 'wp_ajax_nopriv_maic_send_webhook',  'maic_ajax_send_webhook' );

function maic_ajax_send_webhook() {
	check_ajax_referer( 'maic_chat_nonce', 'nonce' );

	$settings = wp_parse_args( get_option( 'maic_settings', array() ), maic_get_defaults() );

	$message    = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );
	$session_id = sanitize_text_field( wp_unslash( $_POST['session_id'] ?? '' ) );
	$user_name  = sanitize_text_field( wp_unslash( $_POST['user_name'] ?? '' ) );
	$user_email = sanitize_email( wp_unslash( $_POST['user_email'] ?? '' ) );
	$user_phone = sanitize_text_field( wp_unslash( $_POST['user_phone'] ?? '' ) );

	$body = array(
		'message'    => $message,
		'session_id' => $session_id,
		'user_info'  => array(
			'name'  => $user_name,
			'email' => $user_email,
			'phone' => $user_phone,
		),
	);

	$api_url = trailingslashit( $settings['api_base_url'] ) . 'webhook';

	$response = wp_remote_post( $api_url, array(
		'timeout' => 15,
		'headers' => array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . $settings['api_key'],
		),
		'body' => wp_json_encode( $body ),
	) );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( array( 'message' => $response->get_error_message() ), 502 );
	}

	wp_send_json_success( array( 'message' => 'Webhook sent.' ) );
}

/*--------------------------------------------------------------
# AJAX: Proxy Analytics (Views/Clicks)
--------------------------------------------------------------*/
add_action( 'wp_ajax_maic_track_event',        'maic_ajax_track_event' );
add_action( 'wp_ajax_nopriv_maic_track_event',  'maic_ajax_track_event' );

function maic_ajax_track_event() {
	check_ajax_referer( 'maic_chat_nonce', 'nonce' );
	$settings = wp_parse_args( get_option( 'maic_settings', array() ), maic_get_defaults() );

	$type = sanitize_text_field( $_POST['type'] ?? '' );
	if ( ! in_array( $type, array( 'view', 'click' ) ) ) {
		wp_send_json_error( array( 'message' => 'Invalid event type.' ) );
	}

	$api_url = trailingslashit( $settings['api_base_url'] ) . 'analytics';

	wp_remote_post( $api_url, array(
		'timeout' => 5,
		'headers' => array( 'Content-Type' => 'application/json' ),
		'body'    => wp_json_encode( array(
			'agent_id' => $settings['agent_id'],
			'type'     => $type
		) ),
	) );

	wp_send_json_success();
}

/*--------------------------------------------------------------
# AJAX: Proxy Fetch Config (Sync)
----------------------------------------------*/
add_action( 'wp_ajax_maic_fetch_config',        'maic_ajax_fetch_config' );
add_action( 'wp_ajax_nopriv_maic_fetch_config',  'maic_ajax_fetch_config' );

function maic_ajax_fetch_config() {
	check_ajax_referer( 'maic_chat_nonce', 'nonce' );
	$settings = wp_parse_args( get_option( 'maic_settings', array() ), maic_get_defaults() );

	if ( empty( $settings['api_base_url'] ) || empty( $settings['agent_id'] ) || empty( $settings['api_key'] ) ) {
		wp_send_json_error( array( 'message' => 'Not configured' ) );
	}

	$api_url = trailingslashit( $settings['api_base_url'] ) . 'api/agents/' . $settings['agent_id'] . '/config';

	$response = wp_remote_get( $api_url, array(
		'timeout' => 15,
		'headers' => array( 'X-Api-Key' => $settings['api_key'] )
	) );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( array( 'message' => $response->get_error_message() ) );
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	wp_send_json_success( $data );
}

/*--------------------------------------------------------------
# Settings link on Plugins page
--------------------------------------------------------------*/
add_filter( 'plugin_action_links_' . MAIC_PLUGIN_BASENAME, 'maic_action_links' );
function maic_action_links( $links ) {
	$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=messenger-ai' ) ) . '">' . __( 'Settings', 'messenger-ai-chatbot' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}
